package Actividad_2;

public interface Promotion {
    double apply(double price);
}
