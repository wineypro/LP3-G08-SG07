package Actividad_2;

import java.util.*;

public class Notifier {
    private List<Observer> users = new ArrayList<>();

    public void add(Observer u) { users.add(u); }

    public void notifyAll(String msg) {
        for (Observer u : users) u.update(msg);
    }
}
