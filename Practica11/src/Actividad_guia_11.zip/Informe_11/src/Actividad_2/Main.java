package Actividad_2;

public class Main {
    public static void main(String[] args) {

        Notifier n = new Notifier();
        n.add(new User("Karim"));

        Product p = new Product(100);

        Command aplicarPromo = new ApplyPromoCommand(p, new Promo10());
        aplicarPromo.execute();

        n.notifyAll("Se aplicó una promo del 10%.");

        System.out.println("Precio final: " + p.finalPrice());
    }
}
