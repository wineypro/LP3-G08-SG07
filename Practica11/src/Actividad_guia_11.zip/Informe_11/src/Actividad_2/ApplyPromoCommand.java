package Actividad_2;

public class ApplyPromoCommand implements Command {
    private Product p;
    private Promotion promo;

    public ApplyPromoCommand(Product p, Promotion promo) {
        this.p = p;
        this.promo = promo;
    }

    public void execute() {
        p.setPromo(promo);
    }
}
