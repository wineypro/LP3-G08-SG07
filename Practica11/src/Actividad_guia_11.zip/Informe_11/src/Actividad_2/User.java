package Actividad_2;

public class User implements Observer {
    private String name;

    public User(String name) { this.name = name; }

    public void update(String msg) {
        System.out.println(name + " recibió: " + msg);
    }
}
