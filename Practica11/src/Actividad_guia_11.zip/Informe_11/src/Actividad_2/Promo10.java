package Actividad_2;

public class Promo10 implements Promotion {
    public double apply(double price) { return price * 0.9; }
}
