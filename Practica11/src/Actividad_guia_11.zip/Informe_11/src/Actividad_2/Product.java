package Actividad_2;

public class Product {
    private double price;
    private Promotion promo;

    public Product(double price) { this.price = price; }

    public void setPromo(Promotion promo) { this.promo = promo; }

    public double finalPrice() { return promo.apply(price); }
}
