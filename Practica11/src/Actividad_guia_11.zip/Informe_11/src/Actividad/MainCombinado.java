package Actividad;

import java.util.*;

// ================= OBSERVER =================
interface Observer {
    void update(String mensaje);
}

class Usuario implements Observer {
    private String nombre;

    public Usuario(String nombre) {
        this.nombre = nombre;
    }

    @Override
    public void update(String mensaje) {
        System.out.println(nombre + " recibió: " + mensaje);
    }
}

class Notificador {
    private List<Observer> usuarios = new ArrayList<>();

    public void suscribir(Observer usuario) {
        usuarios.add(usuario);
    }

    public void desuscribir(Observer usuario) {
        usuarios.remove(usuario);
    }

    public void notificar(String mensaje) {
        for (Observer u : usuarios) {
            u.update(mensaje);
        }
    }
}

// ================= STRATEGY =================
interface DescuentoStrategy {
    double aplicarDescuento(double precio);
}

class SinDescuento implements DescuentoStrategy {
    public double aplicarDescuento(double precio) {
        return precio;
    }
}

class DescuentoFijo implements DescuentoStrategy {
    public double aplicarDescuento(double precio) {
        return precio * 0.9; // 10% descuento
    }
}

class DescuentoEspecial implements DescuentoStrategy {
    public double aplicarDescuento(double precio) {
        return precio * 0.8; // 20% descuento
    }
}

class CalculadoraPrecio {
    private DescuentoStrategy estrategia;

    public void setEstrategia(DescuentoStrategy estrategia) {
        this.estrategia = estrategia;
    }

    public double calcular(double precio) {
        return estrategia.aplicarDescuento(precio);
    }
}

// ================= COMMAND =================
interface Command {
    void execute();
}

class Televisor {
    public void encender() { System.out.println("Televisor encendido"); }
    public void apagar() { System.out.println("Televisor apagado"); }
    public void subirVolumen() { System.out.println("Volumen subido"); }
    public void bajarVolumen() { System.out.println("Volumen bajado"); }
    public void cambiarCanal() { System.out.println("Canal cambiado"); }
}

class EncenderCommand implements Command {
    private Televisor tv;
    public EncenderCommand(Televisor tv) { this.tv = tv; }
    public void execute() { tv.encender(); }
}

class ApagarCommand implements Command {
    private Televisor tv;
    public ApagarCommand(Televisor tv) { this.tv = tv; }
    public void execute() { tv.apagar(); }
}

class SubirVolumenCommand implements Command {
    private Televisor tv;
    public SubirVolumenCommand(Televisor tv) { this.tv = tv; }
    public void execute() { tv.subirVolumen(); }
}

class BajarVolumenCommand implements Command {
    private Televisor tv;
    public BajarVolumenCommand(Televisor tv) { this.tv = tv; }
    public void execute() { tv.bajarVolumen(); }
}

class CambiarCanalCommand implements Command {
    private Televisor tv;
    public CambiarCanalCommand(Televisor tv) { this.tv = tv; }
    public void execute() { tv.cambiarCanal(); }
}

class ControlRemoto {
    private Command comando;
    public void setComando(Command comando) { this.comando = comando; }
    public void presionarBoton() { comando.execute(); }
}

// ================= MAIN COMBINADO =================
public class MainCombinado {
    public static void main(String[] args) {
        // Observer
        Notificador notificador = new Notificador();
        Usuario u1 = new Usuario("Carlos");
        Usuario u2 = new Usuario("Ana");
        notificador.suscribir(u1);
        notificador.suscribir(u2);

        // Strategy
        CalculadoraPrecio calculadora = new CalculadoraPrecio();
        calculadora.setEstrategia(new DescuentoFijo());
        double precio = 100;
        double precioFinal = calculadora.calcular(precio);

        // Command
        Televisor tv = new Televisor();
        ControlRemoto control = new ControlRemoto();
        control.setComando(new EncenderCommand(tv)); control.presionarBoton();
        control.setComando(new SubirVolumenCommand(tv)); control.presionarBoton();
        control.setComando(new CambiarCanalCommand(tv)); control.presionarBoton();
        control.setComando(new BajarVolumenCommand(tv)); control.presionarBoton();
        control.setComando(new ApagarCommand(tv)); control.presionarBoton();

        // Notificación final
        notificador.notificar("Producto con descuento aplicado: " + precioFinal);
    }
}
