package Actividad;

import java.util.ArrayList;
import java.util.List;

// Interfaz Observer
interface Observer {
    void update(String mensaje);
}

// Clase concreta de Observer
class Usuario implements Observer {
    private String nombre;

    public Usuario(String nombre) {
        this.nombre = nombre;
    }

    @Override
    public void update(String mensaje) {
        System.out.println(nombre + " recibió notificación: " + mensaje);
    }
}

// Clase Subject
class Notificador {
    private List<Observer> usuarios = new ArrayList<>();

    public void suscribir(Observer usuario) {
        usuarios.add(usuario);
    }

    public void desuscribir(Observer usuario) {
        usuarios.remove(usuario);
    }

    public void notificar(String mensaje) {
        for (Observer usuario : usuarios) {
            usuario.update(mensaje);
        }
    }
}

// Main
public class MainObserver {
    public static void main(String[] args) {
        Notificador notificador = new Notificador();

        Usuario u1 = new Usuario("Carlos");
        Usuario u2 = new Usuario("Ana");
        Usuario u3 = new Usuario("Luis");

        notificador.suscribir(u1);
        notificador.suscribir(u2);
        notificador.suscribir(u3);

        notificador.notificar("¡Nueva promoción disponible!");
        notificador.desuscribir(u2);
        notificador.notificar("¡Actualización de producto!");
    }
}
