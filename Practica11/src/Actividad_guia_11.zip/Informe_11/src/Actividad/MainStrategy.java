package Actividad;

//Interfaz Strategy
interface DescuentoStrategy {
 double aplicarDescuento(double precio);
}

//Estrategias concretas
class SinDescuento implements DescuentoStrategy {
 public double aplicarDescuento(double precio) {
     return precio;
 }
}

class DescuentoFijo implements DescuentoStrategy {
 public double aplicarDescuento(double precio) {
     return precio * 0.9; // 10% descuento
 }
}

class DescuentoEspecial implements DescuentoStrategy {
 public double aplicarDescuento(double precio) {
     return precio * 0.8; // 20% descuento
 }
}

//Contexto
class CalculadoraPrecio {
 private DescuentoStrategy estrategia;

 public void setEstrategia(DescuentoStrategy estrategia) {
     this.estrategia = estrategia;
 }

 public double calcular(double precio) {
     return estrategia.aplicarDescuento(precio);
 }
}

//Main
public class MainStrategy {
 public static void main(String[] args) {
     CalculadoraPrecio calculadora = new CalculadoraPrecio();

     calculadora.setEstrategia(new SinDescuento());
     System.out.println("Precio sin descuento: " + calculadora.calcular(100));

     calculadora.setEstrategia(new DescuentoFijo());
     System.out.println("Precio con descuento fijo: " + calculadora.calcular(100));

     calculadora.setEstrategia(new DescuentoEspecial());
     System.out.println("Precio con descuento especial: " + calculadora.calcular(100));
 }
}
