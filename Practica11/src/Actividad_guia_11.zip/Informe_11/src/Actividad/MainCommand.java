package Actividad;

//Interfaz Command
interface Command {
 void execute();
}

//Receptor
class Televisor {
 public void encender() { System.out.println("Televisor encendido"); }
 public void apagar() { System.out.println("Televisor apagado"); }
 public void subirVolumen() { System.out.println("Volumen subido"); }
 public void bajarVolumen() { System.out.println("Volumen bajado"); }
 public void cambiarCanal() { System.out.println("Canal cambiado"); }
}

//Comandos concretos
class EncenderCommand implements Command {
 private Televisor tv;
 public EncenderCommand(Televisor tv) { this.tv = tv; }
 public void execute() { tv.encender(); }
}

class ApagarCommand implements Command {
 private Televisor tv;
 public ApagarCommand(Televisor tv) { this.tv = tv; }
 public void execute() { tv.apagar(); }
}

class SubirVolumenCommand implements Command {
 private Televisor tv;
 public SubirVolumenCommand(Televisor tv) { this.tv = tv; }
 public void execute() { tv.subirVolumen(); }
}

class BajarVolumenCommand implements Command {
 private Televisor tv;
 public BajarVolumenCommand(Televisor tv) { this.tv = tv; }
 public void execute() { tv.bajarVolumen(); }
}

class CambiarCanalCommand implements Command {
 private Televisor tv;
 public CambiarCanalCommand(Televisor tv) { this.tv = tv; }
 public void execute() { tv.cambiarCanal(); }
}

//Invocador
class ControlRemoto {
 private Command comando;
 public void setComando(Command comando) { this.comando = comando; }
 public void presionarBoton() { comando.execute(); }
}

//Main
public class MainCommand {
 public static void main(String[] args) {
     Televisor tv = new Televisor();
     ControlRemoto control = new ControlRemoto();

     control.setComando(new EncenderCommand(tv)); control.presionarBoton();
     control.setComando(new SubirVolumenCommand(tv)); control.presionarBoton();
     control.setComando(new CambiarCanalCommand(tv)); control.presionarBoton();
     control.setComando(new BajarVolumenCommand(tv)); control.presionarBoton();
     control.setComando(new ApagarCommand(tv)); control.presionarBoton();
 }
}
