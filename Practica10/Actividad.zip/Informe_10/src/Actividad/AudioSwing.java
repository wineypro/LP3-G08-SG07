package Actividad;

import javax.sound.sampled.*;
import javax.swing.*;
import java.io.File;

public class AudioSwing extends JFrame {
    public AudioSwing() {
        setTitle("Reproductor de Audio");
        setSize(300, 150);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        JButton btnPlay = new JButton("Reproducir Audio");
        btnPlay.addActionListener(e -> reproducir("C:\\ruta\\audio.wav")); // Ajusta la ruta
        add(btnPlay);
    }

    private void reproducir(String ruta) {
        try {
            AudioInputStream audioStream = AudioSystem.getAudioInputStream(new File(ruta));
            Clip clip = AudioSystem.getClip();
            clip.open(audioStream);
            clip.start();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error al reproducir audio: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new AudioSwing().setVisible(true));
    }
}
