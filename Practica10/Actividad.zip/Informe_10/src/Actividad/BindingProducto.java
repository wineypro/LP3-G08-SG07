package Actividad;

import javax.swing.*;
import java.awt.*;

public class BindingProducto extends JFrame {
    private JTextField txtNombre, txtPrecio, txtStock;
    private JComboBox<String> cmbCategoria;
    private JLabel lblResultado;

    public BindingProducto() {
        setTitle("Binding de Datos - Producto");
        setSize(400, 250);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new GridLayout(6, 2));

        add(new JLabel("Nombre:"));
        txtNombre = new JTextField();
        add(txtNombre);

        add(new JLabel("Precio:"));
        txtPrecio = new JTextField();
        add(txtPrecio);

        add(new JLabel("Stock:"));
        txtStock = new JTextField();
        add(txtStock);

        add(new JLabel("Categoría:"));
        cmbCategoria = new JComboBox<>(new String[]{"Electrónica", "Ropa", "Hogar"});
        add(cmbCategoria);

        JButton btnActualizar = new JButton("Actualizar");
        lblResultado = new JLabel("Datos del producto aquí...");
        add(btnActualizar);
        add(lblResultado);

        btnActualizar.addActionListener(e -> {
            String nombre = txtNombre.getText();
            String precio = txtPrecio.getText();
            String stock = txtStock.getText();
            String categoria = (String) cmbCategoria.getSelectedItem();
            lblResultado.setText("<html>Producto: " + nombre + "<br>Precio: " + precio +
                    "<br>Stock: " + stock + "<br>Categoría: " + categoria + "</html>");
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new BindingProducto().setVisible(true));
    }
}
