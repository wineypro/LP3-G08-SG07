package Actividad;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.AffineTransform;

public class GraficosSwing extends JPanel {
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;

        // Gráfico simple
        g.setColor(Color.BLUE);
        g.drawLine(20, 20, 120, 120);
        g.setColor(Color.RED);
        g.drawRect(50, 50, 100, 50);

        // Gráfico avanzado con transformaciones
        AffineTransform original = g2d.getTransform();
        g2d.translate(200, 50);
        g2d.rotate(Math.toRadians(30));
        g2d.setColor(Color.GREEN);
        g2d.fillRect(0, 0, 100, 50);
        g2d.setTransform(original);
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Gráficos en Swing");
        frame.setSize(400, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(new GraficosSwing());
        frame.setVisible(true);
    }
}
