package Actividad;

import javax.swing.*;
import java.awt.*;
import java.util.Arrays;

public class GraficoLineasTemperatura extends JFrame {
    private final String[] dias = {"Lun","Mar","Mié","Jue","Vie","Sáb","Dom"};
    private final JTextField[] campos = new JTextField[dias.length];
    private final JButton btnMostrar = new JButton("Mostrar Gráfico");
    private final PanelGrafico panelGrafico = new PanelGrafico();

    public GraficoLineasTemperatura() {
        setTitle("Gráfico de Líneas - Temperaturas");
        setSize(700, 450);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel top = new JPanel(new GridLayout(2, dias.length));
        for (int i = 0; i < dias.length; i++) {
            top.add(new JLabel(dias[i]));
        }
        for (int i = 0; i < dias.length; i++) {
            campos[i] = new JTextField();
            top.add(campos[i]);
        }

        JPanel north = new JPanel(new BorderLayout());
        north.add(top, BorderLayout.CENTER);
        north.add(btnMostrar, BorderLayout.EAST);

        btnMostrar.addActionListener(e -> {
            try {
                int[] temps = new int[dias.length];
                for (int i = 0; i < dias.length; i++) {
                    temps[i] = Integer.parseInt(campos[i].getText().trim());
                }
                panelGrafico.setDatos(temps);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Ingresa enteros válidos para todas las temperaturas.");
            }
        });

        setLayout(new BorderLayout());
        add(north, BorderLayout.NORTH);
        add(panelGrafico, BorderLayout.CENTER);
    }

    static class PanelGrafico extends JPanel {
        private int[] datos = new int[7];

        public void setDatos(int[] nuevos) {
            this.datos = Arrays.copyOf(nuevos, nuevos.length);
            repaint();
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2d = (Graphics2D) g;
            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            int margenIzq = 60, margenInf = 50;
            int ancho = getWidth() - margenIzq - 40;
            int alto = getHeight() - margenInf - 40;

            int x0 = margenIzq;
            int y0 = getHeight() - margenInf;
            g2d.drawLine(x0, y0, x0, y0 - alto);
            g2d.drawLine(x0, y0, x0 + ancho, y0);

            int max = Arrays.stream(datos).max().orElse(1);
            int min = Arrays.stream(datos).min().orElse(0);
            int rango = Math.max(1, max - min);

            int espacio = ancho / (datos.length - 1);
            int[] xs = new int[datos.length];
            int[] ys = new int[datos.length];

            for (int i = 0; i < datos.length; i++) {
                xs[i] = x0 + i * espacio;
                double norm = (datos[i] - min) / (double) rango;
                ys[i] = (int) (y0 - norm * alto);
            }

            g2d.setColor(Color.BLUE);
            for (int i = 0; i < datos.length - 1; i++) {
                g2d.drawLine(xs[i], ys[i], xs[i+1], ys[i+1]);
            }
            for (int i = 0; i < datos.length; i++) {
                g2d.fillOval(xs[i]-4, ys[i]-4, 8, 8);
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new GraficoLineasTemperatura().setVisible(true));
    }
}
